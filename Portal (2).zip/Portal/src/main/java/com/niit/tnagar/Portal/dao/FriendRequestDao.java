package com.niit.tnagar.Portal.dao;

import java.util.List;

import com.niit.tnagar.Portal.model.FriendRequest;

public interface FriendRequestDao {

	public List<FriendRequest> list();

	public FriendRequest get(String username);  

	public void merge(FriendRequest friendRequest);
	
	public void delete(String username);
}
