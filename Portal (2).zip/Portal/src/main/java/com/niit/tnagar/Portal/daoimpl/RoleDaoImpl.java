package com.niit.tnagar.Portal.daoimpl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.tnagar.Portal.dao.RoleDao;
import com.niit.tnagar.Portal.model.Role;

@Repository("roleDao")
public class RoleDaoImpl implements RoleDao{ 
	
	@Autowired
	private SessionFactory sessionFactory;


	public RoleDaoImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Transactional
	public List<Role> list() {
		@SuppressWarnings("unchecked")
		List<Role> list = (List<Role>) sessionFactory.getCurrentSession()
				.createCriteria(Role.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();

		return list;
	}

	@Transactional
	public void merge(Role role) {
		sessionFactory.getCurrentSession().merge(role);
	}
	

	@Transactional
	public void delete(String roleAssigned) {
		Role role = new Role();
		role.setRoleAssigned(roleAssigned);
		sessionFactory.getCurrentSession().delete(role);
	}

	@Transactional
	public Role get(String roleAssigned) {
		String hql = "from Role where roleAssigned=" + "'"+ roleAssigned+"'";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		
		@SuppressWarnings("unchecked")
		List<Role> list = (List<Role>) query.list();
		
		if (list != null && !list.isEmpty()) {
			return list.get(0);
		}
		
		return null;
	}

}
