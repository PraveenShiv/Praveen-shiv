package com.niit.tnagar.Portal.daoimpl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.tnagar.Portal.dao.FriendRequestDao;
import com.niit.tnagar.Portal.model.FriendRequest;

@Repository("FriendRequestDao")
public class FriendRequestDaoImpl implements FriendRequestDao{
	
	@Autowired
	private SessionFactory sessionFactory;


	public FriendRequestDaoImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Transactional
	public List<FriendRequest> list() {
		@SuppressWarnings("unchecked")
		List<FriendRequest> list = (List<FriendRequest>) sessionFactory.getCurrentSession()
				.createCriteria(FriendRequest.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();

		return list;
	}

	@Transactional
	public void merge(FriendRequest friendRequest) {
		sessionFactory.getCurrentSession().merge(friendRequest);
	}
	

	@Transactional
	public void delete(String username) {
		FriendRequest friendRequest = new FriendRequest();
		friendRequest.setUsername(username);
		sessionFactory.getCurrentSession().delete(friendRequest);
	}

	@Transactional
	public FriendRequest get(String username) {
		String hql = "from FriendRequest where username=" + "'"+ username+"'";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		
		@SuppressWarnings("unchecked")
		List<FriendRequest> list = (List<FriendRequest>) query.list();
		
		if (list != null && !list.isEmpty()) {
			return list.get(0);
		}
		
		return null;
	}  

}
