package com.niit.tnagar.Portal.daoimpl;


import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.tnagar.Portal.dao.EmployeeDetailsDao;
import com.niit.tnagar.Portal.model.EmployeeDetails; 


@Repository("employeeDetailsDao")
public class EmployeeDetailsDaoImpl implements EmployeeDetailsDao{

	@Autowired
	private SessionFactory sessionFactory;


	public EmployeeDetailsDaoImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Transactional
	public List<EmployeeDetails> list() {
		@SuppressWarnings("unchecked")
		List<EmployeeDetails> list = (List<EmployeeDetails>) sessionFactory.getCurrentSession()
				.createCriteria(EmployeeDetails.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();

		return list;
	}

	@Transactional
	public void merge(EmployeeDetails employeeDetails) {
		sessionFactory.getCurrentSession().merge(employeeDetails);
	}
	

	@Transactional
	public void delete(String employeeRegno) {
		EmployeeDetails employeeDetails = new EmployeeDetails();
		employeeDetails.setEmployeeRegno(employeeRegno);
		sessionFactory.getCurrentSession().delete(employeeDetails);
	}

	@Transactional
	public EmployeeDetails get(String employeeRegno) {
		String hql = "from EmployeeDetails where employeeRegno=" + "'"+ employeeRegno+"'";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		
		@SuppressWarnings("unchecked")
		List<EmployeeDetails> list = (List<EmployeeDetails>) query.list();
		
		if (list != null && !list.isEmpty()) {
			return list.get(0);
		}
		
		return null;
	}
}  
