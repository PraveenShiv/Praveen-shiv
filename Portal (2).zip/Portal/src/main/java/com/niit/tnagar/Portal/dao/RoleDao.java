package com.niit.tnagar.Portal.dao;

import java.util.List;

import com.niit.tnagar.Portal.model.Role;

public interface RoleDao {
	public List<Role> list();

	public Role get(String roleAssigned);  

	public void merge(Role role);
	
	public void delete(String roleAssigned);

}
