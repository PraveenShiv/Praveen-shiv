package com.niit.tnagar.Portal.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;
import com.niit.tnagar.Portal.model.User;
import com.niit.tnagar.Portal.model.Role;

@Entity
@Table(name="UserRole")
public class UserRole {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private String userRoleId;
	
	@ManyToOne
	private User user;
    @JoinColumn(name="userId", nullable = false, updatable = false, insertable = false)
   	
	@NotEmpty(message = "The userId must not be empty")
	private String userId;
	
	@ManyToOne
	private Role role;
    @JoinColumn(name="roleId", nullable = false, updatable = false, insertable = false)
   	
	@NotEmpty(message = "The roleId must not be empty")
	private String roleId;
	public String getUserRoleId() {
		return userRoleId;
	}
	public void setUserRoleId(String userRoleId) {
		this.userRoleId = userRoleId;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public Role getRole() {
		return role;
	}
	public void setRole(Role role) {
		this.role = role;
	}
	public String getRoleId() {
		return roleId;
	}
	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}
	
	

	
	
	
	
	
	

}
