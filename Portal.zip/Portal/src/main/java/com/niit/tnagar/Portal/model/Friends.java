package com.niit.tnagar.Portal.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;
import com.niit.tnagar.Portal.model.User;

@Entity
@Table(name="Friends")
public class Friends { 
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private String friendsId; 
	@ManyToOne
	private User user;
    @JoinColumn(name="userId", nullable = false, updatable = false, insertable = false)
   	
	@NotEmpty(message = "The userId must not be empty")
	private String userId;
	
	@JoinColumn(name="username", nullable = false, updatable = false, insertable = false)
	@NotEmpty(message = "The username must not be empty")
	private String username;
	
    @JoinColumn(name="userEmail", nullable = false, updatable = false, insertable = false)
	@NotEmpty(message = "The userEmail must not be empty")
	private String userEmail;
	
    @JoinColumn(name="userMobile", nullable = false, updatable = false, insertable = false)
	@NotEmpty(message = "The userMobile must not be empty")
	private String userMobile;
	public String getFriendsId() {
		return friendsId;
	}
	public void setFriendsId(String friendsId) {
		this.friendsId = friendsId;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getUserMobile() {
		return userMobile;
	}
	public void setUserMobile(String userMobile) {
		this.userMobile = userMobile;
	}

	
}
