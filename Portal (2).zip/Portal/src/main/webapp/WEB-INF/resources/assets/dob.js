// Add proper date check method
jQuery.validator.addMethod('ValidDate', function(value, element) {
  var valid = false;

  // First we're going to check if all three fields were provided. If not return true and check will fire after they're supplied
  if ($("#BirthMonth").val() != '' && $("#BirthDay").val() != '' && $("#BirthYear").val() != '') {
    var birthmonth = parseInt($("#BirthMonth").val(), 10)
    var birthday = parseInt($("#BirthDay").val(), 10)
    var birthyear = parseInt($("#BirthYear").val(), 10)

    var JDate = new Date(birthyear, birthmonth - 1, birthday)

    valid = (birthmonth - 1 == JDate.getMonth() && birthday == JDate.getDate() && birthyear == JDate.getFullYear())
  }

  return valid
})

// Add check for birthdate entry. Validation doesn't seem to like a required hidden field.
jQuery.validator.addMethod('RequiredBirthdate', function(value, element) {
  var valid = false;

  // First we're going to check if all three fields were provided. If not return false
  if ($("#BirthMonth").val() != '' && $("#BirthDay").val() != '' && $("#BirthYear").val() != '') {
    valid = true;
  }
  return valid
})

// Check for proper age
jQuery.validator.addMethod('ValidAge', function(value, element) {
  var valid = true;
  var age = 18


  // First we're going to check if all three fields were provided. If not return true and check will fire after they're supplied
  if ($("#BirthMonth").val() != '' && $("#BirthDay").val() != '' && $("#BirthYear").val() != '') {

    // split birthdate into parts
    var birthmonth = parseInt($("#BirthMonth").val(), 10)
    var birthday = parseInt($("#BirthDay").val(), 10)
    var birthyear = parseInt($("#BirthYear").val(), 10)

    // Convert to javascript date - Remember to subtrack 1 from month since javascript month starts at 0
    var JSbirthdate = new Date(birthyear, birthmonth - 1, birthday)

    // Set current date
    var JScurrdate = new Date()

    // Subtract age from current year
    JScurrdate.setFullYear(JScurrdate.getFullYear() - age)

    // compare dates and return boolean
    valid = (JScurrdate - JSbirthdate) >= 0
  }

  return valid
})

$("#register-form1").validate({
  errorClass: "InvalidField",
  validClass: "ValidField",
  errorElement: "span",
  focusInvalid: false,
  groups: {},
  rules: {
    BirthMonth: {
      RequiredBirthdate: true,
      ValidDate: true,
      ValidAge: true
    },
    BirthDay: {
      RequiredBirthdate: true,
      ValidDate: true,
      ValidAge: true
    },
    BirthYear: {
      RequiredBirthdate: true,
      ValidDate: true,
      ValidAge: true
    }
  },
  messages: {},
  highlight: function(element, errorClass, validClass) {
    $(element).addClass(errorClass).removeClass(validClass);
    if (element.name == "BirthMonth") {
      $(element.form).find("label[for=BirthDate]").addClass(errorClass).removeClass(validClass);
    }
  },
  unhighlight: function(element, errorClass, validClass) {
    $(element).removeClass(errorClass).addClass(validClass);
    if (element.name == "BirthMonth") {
      $(element.form).find("label[for=BirthDate]").removeClass(errorClass).addClass(validClass);
    }
  },
  errorPlacement: function(error, element) {

  },
  debug: true
})
