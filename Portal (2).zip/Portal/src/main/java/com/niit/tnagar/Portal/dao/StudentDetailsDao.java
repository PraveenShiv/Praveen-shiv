package com.niit.tnagar.Portal.dao;

import java.util.List;

import com.niit.tnagar.Portal.model.StudentDetails;

public interface StudentDetailsDao {
	
	public List<StudentDetails> list();

	public StudentDetails get(String studentRegno);  

	public void merge(StudentDetails studentDetails);
	
	public void delete(String studentRegno);

}
