package com.niit.shopping.handler;
import org.springframework.binding.message.MessageBuilder;
import org.springframework.binding.message.MessageContext;
import org.springframework.stereotype.Component;

import com.niit.shopping.model.UserDetails;

@Component

public class RegistrationHandler {
	public UserDetails initFlow(){
		return new UserDetails();
	}

	public String validateDetails(UserDetails userDetails,MessageContext messageContext){
		String status = "success";
		if(userDetails.getZipcode().isEmpty()){
			messageContext.addMessage(new MessageBuilder().error().source(
					"zipcode").defaultText("Zipcode cannot be Empty").build());
			status = "failure";
		}
		if(userDetails.getName().isEmpty()){
			messageContext.addMessage(new MessageBuilder().error().source(
					"name").defaultText("Name cannot be Empty").build());
			status = "failure";
		}
		if(userDetails.getAddress1().isEmpty()){
			messageContext.addMessage(new MessageBuilder().error().source(
					"address1").defaultText("Address line 1 cannot be Empty").build());
			status = "failure";
		}
	
		if(userDetails.getCity().isEmpty()){
			messageContext.addMessage(new MessageBuilder().error().source(
					"city").defaultText("city cannot be Empty").build());
			status = "failure";
		}
		if(userDetails.getState().isEmpty()){
			messageContext.addMessage(new MessageBuilder().error().source(
					"state").defaultText("State cannot be Empty").build());
			status = "failure";
		}
		/*if(userDetails.getAddress2().isEmpty()){
			messageContext.addMessage(new MessageBuilder().error().source(
					"address").defaultText("Address line 2 cannot be Empty").build());
			status = "failure";
		}*/
		
		return status;
	}
}

