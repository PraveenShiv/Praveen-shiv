package com.niit.tnagar.Portal.dao;

import java.util.List;

import com.niit.tnagar.Portal.model.Blog;

public interface BlogDao {
	public List<Blog> list();

	public Blog get(String blogHead);  

	public void merge(Blog blog);
	
	public void delete(String blogHead);

} 
