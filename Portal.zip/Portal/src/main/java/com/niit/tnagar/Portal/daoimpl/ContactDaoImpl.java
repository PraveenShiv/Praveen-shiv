package com.niit.tnagar.Portal.daoimpl;


import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.tnagar.Portal.dao.ContactDao;
import com.niit.tnagar.Portal.model.Contact;


@Repository("contactDao")
public class ContactDaoImpl implements ContactDao{
	
	@Autowired
	private SessionFactory sessionFactory;


	public ContactDaoImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Transactional
	public List<Contact> list() {
		@SuppressWarnings("unchecked")
		List<Contact> list = (List<Contact>) sessionFactory.getCurrentSession()
				.createCriteria(Contact.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();

		return list;
	}

	@Transactional
	public void merge(Contact contact) {
		sessionFactory.getCurrentSession().merge(contact);
	}
	

	@Transactional
	public void delete(String contactQueryno) {
		Contact contact = new Contact();
		contact.setContactQueryno(contactQueryno);
		sessionFactory.getCurrentSession().delete(contact);
	}

	@Transactional
	public Contact get(String contactQueryno) {
		String hql = "from Contact where contactQueryno=" + "'"+ contactQueryno+"'";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		
		@SuppressWarnings("unchecked")
		List<Contact> list = (List<Contact>) query.list();
		
		if (list != null && !list.isEmpty()) {
			return list.get(0);
		}
		
		return null;
	}

}
