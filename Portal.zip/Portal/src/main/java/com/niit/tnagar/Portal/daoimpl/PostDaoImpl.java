package com.niit.tnagar.Portal.daoimpl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.tnagar.Portal.dao.PostDao;
import com.niit.tnagar.Portal.model.Post;

@Repository("postDao")
public class PostDaoImpl implements PostDao{
	
	@Autowired
	private SessionFactory sessionFactory;


	public PostDaoImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Transactional
	public List<Post> list() {
		@SuppressWarnings("unchecked")
		List<Post> list = (List<Post>) sessionFactory.getCurrentSession()
				.createCriteria(Post.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();

		return list;
	}

	@Transactional
	public void merge(Post post) {
		sessionFactory.getCurrentSession().merge(post);
	}
	

	@Transactional
	public void delete(String postBody) {
		Post post = new Post();
		post.setPostBody(postBody);
		sessionFactory.getCurrentSession().delete(post);
	}

	@Transactional
	public Post get(String postBody) {
		String hql = "from Post where postBody=" + "'"+ postBody+"'";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		
		@SuppressWarnings("unchecked")
		List<Post> list = (List<Post>) query.list();
		
		if (list != null && !list.isEmpty()) {
			return list.get(0);
		}
		
		return null; 
	}


}
