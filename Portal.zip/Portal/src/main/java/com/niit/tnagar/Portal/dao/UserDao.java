package com.niit.tnagar.Portal.dao;

import java.util.List;

import com.niit.tnagar.Portal.model.User;

public interface UserDao {
	
	public List<User> list();

	public User get(String username);  

	public void merge(User user);
	
	public void delete(String username);

}
