package com.niit.tnagar.Portal.dao;

import java.util.List;

import com.niit.tnagar.Portal.model.Post;

public interface PostDao {
	
	public List<Post> list();

	public Post get(String postBody);  

	public void merge(Post post);
	
	public void delete(String postBody);

} 
