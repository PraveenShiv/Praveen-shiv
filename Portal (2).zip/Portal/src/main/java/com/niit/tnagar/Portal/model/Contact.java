package com.niit.tnagar.Portal.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;
import com.niit.tnagar.Portal.model.User;

@Entity
@Table(name="Contact")
public class Contact {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private String contactId; 
	@ManyToOne
	private User user;
    @JoinColumn(name="userId", nullable = false, updatable = false, insertable = false)
   	
	@NotEmpty(message = "The userId must not be empty")
	private String userId;
	@NotEmpty(message = "The contactName must not be empty")
	private String contactName;
	@NotEmpty(message = "The contactQueryno must not be empty")
	private String contactQueryno;
	@NotEmpty(message = "The contactDescription must not be empty")
	private String contactDescription;
	@NotEmpty(message = "The contactEmail must not be empty")
	private String contactEmail;
	@NotEmpty(message = "The contactMobile must not be empty")
	private String contactMobile;
	public String getContactId() {
		return contactId;
	}
	public void setContactId(String contactId) {
		this.contactId = contactId;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getContactName() {
		return contactName;
	}
	public void setContactName(String contactName) {
		this.contactName = contactName;
	}
	
	public String getContactQueryno() {
		return contactQueryno;
	}
	public void setContactQueryno(String contactQueryno) {
		this.contactQueryno = contactQueryno;
	}
	public String getContactDescription() {
		return contactDescription;
	}
	public void setContactDescription(String contactDescription) {
		this.contactDescription = contactDescription;
	}
	public String getContactEmail() {
		return contactEmail;
	}
	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}
	public String getContactMobile() {
		return contactMobile;
	}
	public void setContactMobile(String contactMobile) {
		this.contactMobile = contactMobile;
	}
	

}
