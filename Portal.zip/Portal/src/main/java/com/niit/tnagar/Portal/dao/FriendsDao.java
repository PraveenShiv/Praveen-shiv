package com.niit.tnagar.Portal.dao;

import java.util.List;

import com.niit.tnagar.Portal.model.Friends;

public interface FriendsDao {

	public List<Friends> list();

	public Friends get(String username);  

	public void merge(Friends friends);
	
	public void delete(String username); 
}
