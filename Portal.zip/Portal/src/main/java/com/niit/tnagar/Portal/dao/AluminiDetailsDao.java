package com.niit.tnagar.Portal.dao;

import java.util.List;

import com.niit.tnagar.Portal.model.AluminiDetails;

public interface AluminiDetailsDao {
	
	public List<AluminiDetails> list();

	public AluminiDetails get(String aluminiRegno);  

	public void merge(AluminiDetails aluminiDetails);
	
	public void delete(String aluminiRegno);

} 
